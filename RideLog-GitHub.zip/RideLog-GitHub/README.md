# Ride Log — Android native conversion

This project wraps the existing Ride Log HTML UI in an Android WebView and moves GPS tracking into a native Android foreground service.

## Open/build
1. Open this folder in Android Studio (Koala 2024.1.1 or newer is recommended).
2. Let Gradle sync/download dependencies.
3. Connect an Android phone or start an emulator.
4. Run the `app` configuration.

## Tracking behavior
- Start Ride requests Android location permission.
- GPS runs from a native foreground service using high-accuracy fused location.
- Tracking continues with the screen locked and while another app is in the foreground.
- A persistent Ride Log notification is shown while tracking.
- Route points and marked spots are stored in SQLite, not browser localStorage.
- GPX/KML exports are saved to `Downloads/Ride Log` on Android 10+.

## Important Android permission note
The app intentionally starts the location foreground service from the visible activity after the user taps Start Ride. Do not change this to silently start location tracking in the background. If publishing to Google Play, complete the Play Console location declarations and privacy disclosures required for your use case.

## Project structure
- `app/src/main/assets/index.html` — your existing UI, adapted to call the native bridge on Android.
- `LocationService.kt` — background/foreground GPS recorder.
- `RideDb.kt` — native SQLite persistence for rides, points and marks.
- `MainActivity.kt` — WebView + JavaScript bridge + Android file export.
