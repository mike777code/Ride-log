package com.ridelog.app

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import android.provider.MediaStore
import android.content.ContentValues
import java.io.File
import java.io.FileOutputStream
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity: AppCompatActivity(){
    private lateinit var web:WebView; private lateinit var db:RideDb
    private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){ when(i?.action){LocationService.ACTION_UPDATE->web.evaluateJavascript("window.nativeLocationUpdate(${JSONObject().apply{put("lat",i.getDoubleExtra("lat",0.0));put("lng",i.getDoubleExtra("lng",0.0));put("t",i.getLongExtra("t",0));put("speed",i.getFloatExtra("speed",0f));put("accuracy",i.getFloatExtra("accuracy",0f));put("distance",i.getDoubleExtra("distance",0.0));put("start",i.getLongExtra("start",0))}})",null);LocationService.ACTION_STOPPED->web.evaluateJavascript("window.nativeRideStopped(${JSONObject().apply{put("id",i.getStringExtra("id") ?: "");put("start",i.getLongExtra("start",0));put("end",i.getLongExtra("end",0));put("distance",i.getDoubleExtra("distance",0.0))}})",null)}}}
    override fun onCreate(b:Bundle?){super.onCreate(b);db=RideDb(this);web=WebView(this);setContentView(web); web.settings.javaScriptEnabled=true;web.settings.domStorageEnabled=true;web.settings.allowFileAccess=true;web.settings.allowContentAccess=true;web.webViewClient=WebViewClient();web.addJavascriptInterface(Bridge(),"Android");web.loadUrl("file:///android_asset/index.html");registerReceiver(receiver,IntentFilter().apply{addAction(LocationService.ACTION_UPDATE);addAction(LocationService.ACTION_STOPPED)},Context.RECEIVER_NOT_EXPORTED)}
    inner class Bridge{ @JavascriptInterface fun startTracking(){ if(!hasLocation()){runOnUiThread{requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),42)};return}; ContextCompat.startForegroundService(this@MainActivity,Intent(this@MainActivity,LocationService::class.java).setAction(LocationService.ACTION_START)) }
        @JavascriptInterface fun stopTracking(){startService(Intent(this@MainActivity,LocationService::class.java).setAction(LocationService.ACTION_STOP))}
        @JavascriptInterface fun addMark(lat:Double,lng:Double,name:String){startService(Intent(this@MainActivity,LocationService::class.java).setAction(LocationService.ACTION_MARK).apply{putExtra("lat",lat);putExtra("lng",lng);putExtra("name",name)})}
        @JavascriptInterface fun saveFile(filename:String,content:String,mime:String):Boolean { return try { val cv=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,filename);put(MediaStore.Downloads.MIME_TYPE,mime);put(MediaStore.Downloads.RELATIVE_PATH,"Download/Ride Log")} ; val uri=contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv) ?: return false; contentResolver.openOutputStream(uri)?.use{it.write(content.toByteArray(Charsets.UTF_8))}; true } catch(e:Exception){false} }
        @JavascriptInterface fun isTracking():Boolean=getSharedPreferences("tracking",0).getBoolean("active",false)
        @JavascriptInterface fun getTrackingState():String { val p=getSharedPreferences("tracking",0); return JSONObject().apply{put("active",p.getBoolean("active",false));put("start",p.getLong("start",0L));put("distance",p.getFloat("distance",0f));put("points",db.currentPoints())}.toString() }
        @JavascriptInterface fun getRides():String=db.summaries().toString()
        @JavascriptInterface fun getRide(id:String):String=db.rideData(id).toString()
        @JavascriptInterface fun deleteRide(id:String){db.deleteRide(id)}
    }
    private fun hasLocation()=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){super.onRequestPermissionsResult(r,p,g);if(r==42&&hasLocation())web.evaluateJavascript("window.androidPermissionGranted()",null)else if(r==42)Toast.makeText(this,"Location permission is required to record a ride.",Toast.LENGTH_LONG).show()}
    override fun onDestroy(){unregisterReceiver(receiver);web.destroy();super.onDestroy()}
}
