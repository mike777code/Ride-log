package com.ridelog.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class RideDb(context: Context) : SQLiteOpenHelper(context, "rides.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE rides (id TEXT PRIMARY KEY, start_ms INTEGER, end_ms INTEGER, distance_km REAL, duration_sec REAL)")
        db.execSQL("CREATE TABLE points (ride_id TEXT, t_ms INTEGER, lat REAL, lng REAL, speed REAL, accuracy REAL)")
        db.execSQL("CREATE TABLE marks (ride_id TEXT, t_ms INTEGER, lat REAL, lng REAL, name TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun startRide(startMs: Long) {
        writableDatabase.execSQL("DELETE FROM points WHERE ride_id='__current__'"); writableDatabase.execSQL("DELETE FROM marks WHERE ride_id='__current__'")
    }
    fun addPoint(t: Long, lat: Double, lng: Double, speed: Float, accuracy: Float) {
        val v = ContentValues().apply { put("ride_id", "__current__"); put("t_ms", t); put("lat", lat); put("lng", lng); put("speed", speed); put("accuracy", accuracy) }
        writableDatabase.insert("points", null, v)
    }

    fun addMark(t: Long, lat: Double, lng: Double, name: String) {
        val v=ContentValues().apply{put("ride_id","__current__");put("t_ms",t);put("lat",lat);put("lng",lng);put("name",name)}
        writableDatabase.insert("marks",null,v)
    }
    fun currentPoints(): JSONArray {
        val a = JSONArray(); val c = readableDatabase.rawQuery("SELECT t_ms,lat,lng,speed,accuracy FROM points WHERE ride_id='__current__' ORDER BY t_ms", null)
        c.use { while (it.moveToNext()) a.put(JSONObject().apply { put("t", it.getLong(0)); put("lat", it.getDouble(1)); put("lng", it.getDouble(2)); put("speed", it.getDouble(3)); put("accuracy", it.getDouble(4)) }) }
        return a
    }
    fun finishRide(startMs: Long, endMs: Long, distanceKm: Double): String? {
        val pts = currentPoints(); if (pts.length < 2) return null
        val id = "r$endMs"
        writableDatabase.beginTransaction()
        try {
            val v = ContentValues().apply { put("id", id); put("start_ms", startMs); put("end_ms", endMs); put("distance_km", distanceKm); put("duration_sec", (endMs-startMs)/1000.0) }
            writableDatabase.insert("rides", null, v)
            val c = readableDatabase.rawQuery("SELECT t_ms,lat,lng,speed,accuracy FROM points WHERE ride_id='__current__' ORDER BY t_ms", null)
            c.use { while(it.moveToNext()) { val p=ContentValues().apply{put("ride_id",id);put("t_ms",it.getLong(0));put("lat",it.getDouble(1));put("lng",it.getDouble(2));put("speed",it.getDouble(3));put("accuracy",it.getDouble(4))}; writableDatabase.insert("points",null,p) } }
            val mc=readableDatabase.rawQuery("SELECT t_ms,lat,lng,name FROM marks WHERE ride_id='__current__'",null); mc.use{while(it.moveToNext()){val m=ContentValues().apply{put("ride_id",id);put("t_ms",it.getLong(0));put("lat",it.getDouble(1));put("lng",it.getDouble(2));put("name",it.getString(3))};writableDatabase.insert("marks",null,m)}}
            writableDatabase.delete("points", "ride_id='__current__'", null); writableDatabase.delete("marks", "ride_id='__current__'", null); writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
        return id
    }
    private fun markCount(id:String):Int { val c=readableDatabase.rawQuery("SELECT COUNT(*) FROM marks WHERE ride_id=?",arrayOf(id)); c.use{it.moveToFirst();return it.getInt(0)} }
    fun summaries(): JSONArray { val a=JSONArray(); val c=readableDatabase.rawQuery("SELECT id,start_ms,end_ms,distance_km,duration_sec FROM rides ORDER BY start_ms DESC",null); c.use{while(it.moveToNext()) a.put(JSONObject().apply{put("id",it.getString(0));put("startTime",it.getLong(1));put("endTime",it.getLong(2));put("distanceKm",it.getDouble(3));put("durationSec",it.getDouble(4));put("markCount", markCount(it.getString(0)))})}; return a }
    fun rideData(id:String): JSONObject { val out=JSONObject(); val pts=JSONArray(); val c=readableDatabase.rawQuery("SELECT t_ms,lat,lng,speed,accuracy FROM points WHERE ride_id=? ORDER BY t_ms",arrayOf(id)); c.use{while(it.moveToNext()) pts.put(JSONObject().apply{put("t",it.getLong(0));put("lat",it.getDouble(1));put("lng",it.getDouble(2));put("speed",it.getDouble(3));put("accuracy",it.getDouble(4))})}; out.put("points",pts); val marks=JSONArray(); val m=readableDatabase.rawQuery("SELECT t_ms,lat,lng,name FROM marks WHERE ride_id=? ORDER BY t_ms",arrayOf(id)); m.use{while(it.moveToNext()) marks.put(JSONObject().apply{put("t",it.getLong(0));put("lat",it.getDouble(1));put("lng",it.getDouble(2));put("name",it.getString(3))})}; out.put("marks",marks); return out }
    fun deleteRide(id:String){ writableDatabase.delete("points","ride_id=?",arrayOf(id)); writableDatabase.delete("marks","ride_id=?",arrayOf(id)); writableDatabase.delete("rides","id=?",arrayOf(id)) }
}
