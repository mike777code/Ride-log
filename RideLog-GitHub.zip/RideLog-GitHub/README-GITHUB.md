# RideLog — phone-only APK build

This repository is set up so GitHub Actions builds an installable Android APK automatically.

## Build from your phone

1. Create a new GitHub repository (for example `RideLog`).
2. Upload **all contents of this ZIP** to the repository root. Do not upload the ZIP itself.
3. Commit to `main` (or `master`). The workflow will start automatically.
4. Open the repository's **Actions** tab and select **Build RideLog APK**.
5. Open the completed workflow run.
6. Under **Artifacts**, download **RideLog-APK**.
7. Extract the downloaded artifact and install `RideLog.apk` on Android.

You can also run it manually from **Actions → Build RideLog APK → Run workflow**.

## What the APK contains

- Existing RideLog HTML/Leaflet interface in an Android WebView.
- Native Android foreground location service.
- Screen-off/background ride tracking after the user starts a ride.
- Native SQLite ride/point persistence.
- JavaScript ↔ Android bridge.
- GPX/KML export support.

## Important

This workflow creates a **debug APK** for personal installation/testing. It is not a Play Store release build.

When installing, Android may ask you to allow location access and notification permission. Start tracking while the app is open so Android can start the location foreground service correctly.
