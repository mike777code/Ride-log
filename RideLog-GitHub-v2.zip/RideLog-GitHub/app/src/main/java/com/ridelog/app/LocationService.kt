package com.ridelog.app

import android.app.*
import android.content.Intent
import android.os.IBinder
import android.os.Looper
import com.google.android.gms.location.*
import android.location.Location

class LocationService : Service() {
    private lateinit var client: FusedLocationProviderClient
    private lateinit var db: RideDb
    private var startMs=0L; private var last: Location?=null; private var distance=0.0
    override fun onCreate(){ super.onCreate(); client=LocationServices.getFusedLocationProviderClient(this); db=RideDb(this); createChannel(); val p=getSharedPreferences("tracking",0); if(p.getBoolean("active",false)){ startMs=p.getLong("start",0L); distance=p.getFloat("distance",0f).toDouble(); } }
    override fun onStartCommand(intent: Intent?, flags:Int, startId:Int):Int {
        when(intent?.action){ null -> if(startMs!=0L) startTracking(); ACTION_START -> startTracking(); ACTION_STOP -> stopTracking(); ACTION_MARK -> db.addMark(System.currentTimeMillis(), intent.getDoubleExtra("lat",0.0), intent.getDoubleExtra("lng",0.0), intent.getStringExtra("name") ?: "Marked spot") }
        return START_STICKY
    }
    private fun startTracking(){ val wasActive=startMs!=0L; if(!wasActive){ startMs=System.currentTimeMillis(); last=null; distance=0.0; db.startRide(startMs) } getSharedPreferences("tracking",0).edit().putBoolean("active",true).putLong("start",startMs).putFloat("distance",distance.toFloat()).apply()
        val n=Notification.Builder(this,CHANNEL).setContentTitle("Ride Log").setContentText("Recording your ride").setSmallIcon(com.ridelog.app.R.drawable.icon_192).setOngoing(true).build()
        startForeground(10,n)
        val req=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000L).setMinUpdateIntervalMillis(500L).setMaxUpdateDelayMillis(2000L).build()
        try{ client.requestLocationUpdates(req, callback, Looper.getMainLooper()) }catch(_:SecurityException){ stopSelf() }
    }
    private val callback=object: LocationCallback(){ override fun onLocationResult(r:LocationResult){ for(l in r.locations){ if(l.accuracy>80f)continue; last?.let{distance += it.distanceTo(l)/1000.0}; last=l; db.addPoint(System.currentTimeMillis(),l.latitude,l.longitude,l.speed,l.accuracy); getSharedPreferences("tracking",0).edit().putFloat("distance",distance.toFloat()).apply(); sendUpdate(l) } } }
    private fun sendUpdate(l:Location){ sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).apply{putExtra("lat",l.latitude);putExtra("lng",l.longitude);putExtra("t",System.currentTimeMillis());putExtra("speed",l.speed);putExtra("accuracy",l.accuracy);putExtra("distance",distance);putExtra("start",startMs)}) }
    private fun stopTracking(){ if(startMs==0L)return; client.removeLocationUpdates(callback); val end=System.currentTimeMillis(); val id=db.finishRide(startMs,end,distance); sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName).apply{putExtra("id",id ?: "");putExtra("start",startMs);putExtra("end",end);putExtra("distance",distance)}); startMs=0L; getSharedPreferences("tracking",0).edit().clear().apply(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
    private fun createChannel(){ val nm=getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel(CHANNEL,"Ride tracking",NotificationManager.IMPORTANCE_LOW)) }
    override fun onBind(i:Intent?):IBinder?=null
    companion object{const val CHANNEL="ride_tracking";const val ACTION_START="com.ridelog.app.START";const val ACTION_MARK="com.ridelog.app.MARK";const val ACTION_STOP="com.ridelog.app.STOP";const val ACTION_UPDATE="com.ridelog.app.UPDATE";const val ACTION_STOPPED="com.ridelog.app.STOPPED"}
}
